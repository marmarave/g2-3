package org.springframework.samples.petclinic.service.businessrules;

public class ElementInCollectionValidator {

}
